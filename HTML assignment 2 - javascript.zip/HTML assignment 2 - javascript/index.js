let price;
function displayPrice() {
    let item = document.getElementById("electronics");
    price = document.getElementById("price").value = item.options[item.selectedIndex].value;
}

function computeDisc(percentage) {
    let discount = percentage*price;
    let disc_price = price-discount;
    document.getElementById("disc_price").value=disc_price;
}

function success(){
    alert("Payment Successful");
}