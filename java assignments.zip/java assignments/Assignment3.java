package myPack;

public class Assignment3 {

	//create a method to swap two numbers
	
	public static void SwapNumber(int num1, int num2) {

		//initialize variable
		int x = num1; // assign the num1 parameter to x
		int y = num2; // assign the num2 parameter to y
		int temp = 0;
		System.out.println("Before Swap");

		System.out.println("the value of x is: " + x);

		System.out.println("the value of y is: " + y);

		System.out.println("After Swap");

		temp = x;
		x = y;
		y = temp;

		System.out.println("the value of x is: " + x);

		System.out.println("the value of y is: " + y);

	}

	public static void main(String[] args) {

		int x = 1;
		int y = 2;

		SwapNumber(x, y);

	}

}
