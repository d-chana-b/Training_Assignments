package myPack;

import java.util.Scanner;

public class Assignment4 {

	// write a switch cases to perform certain calculation
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);		
		
		
		while (true) {
		
			
			
			System.out.print("Enter 1st number:");
			int num1 = sc.nextInt();
			System.out.print("Enter 2nd number:");
			int num2 = sc.nextInt();
			
			
			System.out.print("What operation?");
			char operation = sc.next().charAt(0);
			
			switch (operation) {
			
			case '+':
				System.out.println("Add two numbers;");
				int sum = num1 + num2;
				System.out.println("the sum of two number: "+ sum);
				break;
			case '-':
				System.out.println("Subtract two numbers;");
				int diff = num1 - num2;
				System.out.println("the difference of two number: "+ diff);
				break;
			case '*':
				System.out.println("Multiply two numbers;");
				int product = num1 * num2;
				System.out.println("the product of two number: "+ product);
				break;
			case '/':
				System.out.println("Divide two numbers;");
				int quotient = num1 / num2;
				System.out.println("the quotient of two number: "+ quotient);
				break;
			case 'q':
				System.out.println("bye");
				System.exit(0);
			
			}
		}
		
		

	}

}
